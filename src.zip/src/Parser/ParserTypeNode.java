package Parser;

public interface ParserTypeNode {
    public String getTypeName();
}
