package Parser;

public interface ParserExecutionNode {
    void execute();
    String toString();
}