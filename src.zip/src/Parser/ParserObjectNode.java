package Parser;

/**
 * Interface for classes containing the objects
 */
public interface ParserObjectNode {
}
