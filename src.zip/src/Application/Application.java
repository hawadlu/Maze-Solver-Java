package Application;

import GUI.GUI;

/**
 * This class is the entry point to the program.
 * It provides communication interfaces between most of the other modules
 */
public class Application {

  /**
   * Start the GUI as soon as the program starts
   * @param args any command line arguments
   */
  public static void main(String[] args) {
    new GUI();
  }
}
