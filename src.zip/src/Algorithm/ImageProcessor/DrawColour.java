package Algorithm.ImageProcessor;

import java.awt.*;

/**
 * This class holds the colours for drawing the maze
 */
public class DrawColour {
    Color drawCol;

    public DrawColour(Color draw) {drawCol = draw;}

    public Color getDrawCol() {return drawCol;}
}
